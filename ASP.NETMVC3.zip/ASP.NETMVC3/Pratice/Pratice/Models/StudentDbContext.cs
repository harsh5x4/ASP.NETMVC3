﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;


namespace Pratice.Models
{
    public class StudentDbContext:DbContext
    {
        public StudentDbContext() : base("name=StudentDbContext") { }

        public DbSet<Student_138222> Students { get; set; }
    }
}