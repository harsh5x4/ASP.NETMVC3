﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Pratice.Models; // reference for models

namespace Pratice.Controllers
{
    public class StudentController : Controller
    {
        // GET: Student
        public ActionResult Index()
        {
            StudentDbContext db = new StudentDbContext();
            return View(db.Students);
        }

        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Student_138222 stud)
        {
            StudentDbContext db = new StudentDbContext();
            db.Students.Add(stud);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}