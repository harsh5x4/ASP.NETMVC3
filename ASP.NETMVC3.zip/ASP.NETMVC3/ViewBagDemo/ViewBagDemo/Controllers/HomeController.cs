﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ViewBagDemo.Controllers
{
    [RoutePrefix("Home")]
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            //string Name = "Shiva";
            //ViewBag.ControllerData = Name;

            //ViewData["ControllerData"] = Name;

            string[] Names = { "Harshit", "Tanvee", "Suresh", "Nikita" };
            ViewBag.ControllerData = Names;     

            return View();
        }

        [Route("GetEmp/{id?}")]
        public ActionResult GetAllEmployees()
        {
            return View();
        }


        [Route("Search")]
        public ActionResult SearchEmployee()
        {
            return View();
        }


        [Route("~/Del")]
        public ActionResult DeleteEmployee()
        {
            return View();
        }

    }
}
