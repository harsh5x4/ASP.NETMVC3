﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Optimization;

namespace OptimizationandBundle.App_Start
{
    public class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/Scripts/ScriptBundle").Include("~/Scripts/JavaScript1.js").Include("~/Scripts/JavaScript2.js").Include("~/Scripts/JavaScript3.js"));

            bundles.Add(new StyleBundle("~/Content/CSS")
                .Include("~/Content/bootstrap.css",
                "~/Content/Site.css",
                "~/Content/MyStyle.css"));

            BundleTable.EnableOptimizations = true;
        }
    }
}