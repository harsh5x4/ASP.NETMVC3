﻿function btnClick()
{
    //Button Click
    alert("Hello....")
}