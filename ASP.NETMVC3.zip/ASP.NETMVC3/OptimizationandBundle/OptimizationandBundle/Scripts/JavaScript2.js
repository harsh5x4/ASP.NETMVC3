﻿function LinkbtnClick() {
    //Button Click
    alert("Hello....")
}